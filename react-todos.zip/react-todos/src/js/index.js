/**
 * Created by jiaaobo on 16/3/1.
 */

import App from "./component/app";



React.render(<App/>, document.getElementById("app"));