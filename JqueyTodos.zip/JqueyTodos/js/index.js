/**
 * Created by jiaaobo on 16/3/2.
 */

var UI = {
    $TODO_LIST: $("#todo-list"),
    $TASK_TEXT: $("#taskText"),
    $DONE_COUNT: $("#doneCount"),
    $TOTAL_COUNT: $("#totalCount")
};

var todoList = [];


var Event = {

    init: function () {

        //添加todo
        UI.$TASK_TEXT.bind("keyup", function (e) {

            if (e.keyCode == 13) {
                var text = $(this).val();
                if (!text) return;

               var todoItem = {
                    text: text,
                    ck: false
                }

                todoList.push(todoItem);
                $(this).val("");

                refreshTodoList();

                UI.$TOTAL_COUNT.html(UI.$TOTAL_COUNT.html() - 0 + 1);

            }

        });

        //切换状态
        UI.$TODO_LIST.on("change",".status",function(e){
            if(this.checked){
                UI.$DONE_COUNT.html(UI.$DONE_COUNT.html() - 0 + 1);
                $(this).parent().find("span").css({"text-decoration" : "line-through"});
            }
            else{
                $(this).parent().find("span").css({"text-decoration" : "none"});
                UI.$DONE_COUNT.html(UI.$DONE_COUNT.html() - 1);
            }





        });

        //删除todo
        UI.$TODO_LIST.on("click", ".remove", function (e) {
            console.log("delete..");
            var index = $(this).parent().attr("index");
            todoList.splice(index,1);

            UI.$TOTAL_COUNT.html(UI.$TOTAL_COUNT.html() - 0 - 1);

            if(UI.$DONE_COUNT.html() > 0)
                UI.$DONE_COUNT.html(UI.$DONE_COUNT.html() - 0 - 1);

            $(this).parent().remove();

        });

        //悬浮
        UI.$TODO_LIST.on("mouseenter", "li", function (e) {
            $(this).find(".remove").css("display","block");
        });
        UI.$TODO_LIST.on("mouseleave", "li", function (e) {
            $(this).find(".remove").css("display","none");
        });

        ////切换状态todo
        //UI.$TODO_LIST.on("change", ".status", function (e) {
        //    refreshTodoList();
        //});


    }
};




var refreshTodoList = function () {

    UI.$TODO_LIST.html("");

    for (var i = 0; i < todoList.length; i++) {
        var todo = todoList[i];

        var $li = $('<li index="'+i+'">' +
            '<input type="checkbox" name="ck"  class="status"/>' +
            '<span style="text-decoration: none;">'+todo.text+'</span>' +
            '<button style="display: none;" class="fr remove">删除</button>' +
            '</li>');

        todo.ck ?   $li.find(".status").attr("checked","checked") : $li.find(".status").removeAttr("checked");
        UI.$TODO_LIST.append($li);
    }

}


$(function () {
    Event.init();
});