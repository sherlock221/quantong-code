/**
 * Created by jiaaobo on 16/3/2.
 */

AppModule.controller("AppFooterController", function ($scope,$rootScope) {



});

